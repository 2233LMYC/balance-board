# TCP_Server_Client_Replace_UART

#### 介绍
Server与Client通过各自的串口可实现透传。可直接将原本的UART替代为WIFI无线传输。

TCP Server端程序（Arduino）

TCP Client端（AT指令配置）

TCP Client端（Arduino 不推荐使用（快速通信有问题，原因暂不明））

模块 ESP8266/8285

